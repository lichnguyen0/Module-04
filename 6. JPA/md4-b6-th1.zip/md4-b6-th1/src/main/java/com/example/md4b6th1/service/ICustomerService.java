package com.example.md4b6th1.service;

import com.example.md4b6th1.model.Customer;

public interface ICustomerService extends IGenerateService<Customer> {
}
