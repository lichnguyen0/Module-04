package com.example.md4b6th1.repository;

import com.example.md4b6th1.model.Customer;

public interface ICustomerRepository extends IGenerateRepository<Customer>{
}
